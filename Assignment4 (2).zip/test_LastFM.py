import unittest
from LastFM import LastFM,top_artist
#python -m pytest --cov=LastFM
#
'''unit test for LastFM'''
class unit_test_LastFM(unittest.TestCase):
 
    def test_brazil(self,message:str = "@lastfm", apikey = "f01737f82a234f89d5e7b49929d2adb0",country = "Brazil"):
        lastfm = LastFM(country)
        lastfm.set_apikey(apikey)
        lastfm.transclude(message)
        top = top_artist(country) 
        assert top == "Rihanna"

    def test_brazil_message(self,message:str = "Test case two @lastfm in Mexico", apikey = "f01737f82a234f89d5e7b49929d2adb0",country = "Mexico"):
        lastfm = LastFM(country)
        lastfm.set_apikey(apikey)
        new_message = lastfm.transclude(message)
        assert new_message == "Test case two Radiohead in Mexico"
    
    def test_wrong_api(self, message="Testing should be wrong @lastfm", apikey="f01737f82a234f89d5e7b49929d2adb0", country="fakefakefake"):
        lastfm = LastFM(country)
        lastfm.set_apikey(apikey)
        data = lastfm.load_data()
        assert data == None
