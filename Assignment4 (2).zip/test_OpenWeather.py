import unittest
from OpenWeather import OpenWeather,current_weather,main
from WebAPI import WebAPI
'''unit test for OpenWeather'''
class unit_test_LastFM(unittest.TestCase):
#python -m pytest --cov=OpenWeather
    def test_weather(self, message="@weather", apikey="f01737f82a234f89d5e7b49929d2adb0", zipcode="92697", ccode="US"):
        open_weather = OpenWeather(zipcode, ccode)
        open_weather.set_apikey(apikey)
        open_weather.load_data()
        rightish = open_weather.weather
        assert open_weather.weather == rightish
    
    def message(self,message:str = "@weather is blank", apikey = "f01737f82a234f89d5e7b49929d2adb0", zipcode = "92697", ccode = "US"):
        open_weather = OpenWeather(zipcode, ccode)
        open_weather.set_apikey(apikey)
        newmsg = open_weather.transclude(message)
        data = WebAPI._download_url("http://api.openweathermap.org/data/2.5/weather?zip={zipcode},{ccode}&units=imperial&appid={apikey}")
        assert newmsg == f'{open_weather.description} is blank'
    
    def load_data_attributes(self, apikey = "f01737f82a234f89d5e7b49929d2adb0", zipcode = "92697", ccode = "US"):
        open_weather = OpenWeather(zipcode, ccode)
        open_weather.set_apikey(apikey)
        open_weather.transclude("@weather")
        self.assertIsNotNone(open_weather.longitude)
        self.assertIsNotNone(open_weather.latitude)
        self.assertIsNotNone(open_weather.weather)
        self.assertIsNotNone(open_weather.description)
        self.assertIsNotNone(open_weather.temperature)
        self.assertIsNotNone(open_weather.low_temperature)
        self.assertIsNotNone(open_weather.high_temperature)
        self.assertIsNotNone(open_weather.humidity)
        self.assertIsNotNone(open_weather.sunset)
        self.assertIsNotNone(open_weather.city)
    
    def right_test(zipcode = "92697", ccode = "US",message = "@weather", apikey = "f01737f82a234f89d5e7b49929d2adb0"):
        open_weather = OpenWeather(zipcode, ccode)
        open_weather.set_apikey(apikey)
        open_weather.load_data()
        messagenew = open_weather.transclude("@weather")
        random = open_weather.weather
        assert messagenew == f'{random}'

    def test_main_function(self):
        zipcode = "92697"
        ccode = "US"
        expected_result = current_weather(zipcode, ccode)
        assert main(zipcode, ccode) == expected_result