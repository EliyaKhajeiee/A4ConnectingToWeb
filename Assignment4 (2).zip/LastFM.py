# lastfm.py

# Starter code for assignment 4 in ICS 32
# Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie 
# ekhajeie@uci.edu
# 85362437
import urllib.request
import urllib.error
from WebAPI import WebAPI
import re
import unittest

'''LastFM module which runs the LastFM api and returns data in terms of json data'''
class LastFM(WebAPI): #f01737f82a234f89d5e7b49929d2adb0, 88336d2234389d428601694292cb810c
    '''Class that runs the LastFM api'''

    def __init__(self,country="Brazil"):
        '''init function to instansiate my class'''
        super().__init__()
        self.country = country

    def set_apikey(self, apikey="f01737f82a234f89d5e7b49929d2adb0") -> None:
        '''set the APIkey given from the API'''
        self.apikey = apikey


    def load_data(self) -> None:
        '''returns back given values from the json file of the API'''
        try:
            url = f'http://ws.audioscrobbler.com/2.0/?method=geo.gettopartists&country={self.country}&api_key={self.apikey}&format=json'
            data = super()._download_url(url)
            if 'error' in data and data['error'] in [2,3,4,5,6,7,8,9,10,11,13,16,26,29]:
                error_message = data['message']
                print(error_message)
            else:
                self.top_artist = data['topartists']['artist'][0]['name']
        except (KeyError, TypeError) as e:
            print("You have inputted a wrong commpand, try again",e)
            quit()
    
    def transclude(self, message:str) -> str:
        '''
        Replaces keywords in a message with associated API data.
        :param message: The message to transclude
            
        :returns: The transcluded message
        '''
        if len(message) > 0 and not message.isspace():
            if re.search(r"@\blastfm\b(?!([\w-]+))", message):
                replaceW = main(self.country)
                message = message.replace("@lastfm", replaceW)
                return message #new message 
            else:
                pass

def top_artist(country: str = "Brazil") -> str:
    '''returns the top artist from the given country'''
    lastfm = LastFM(country)
    lastfm.set_apikey()
    lastfm.load_data()
    return lastfm.top_artist 

def main(country):
    '''main function to run the rest of my code'''
    TA = top_artist(country)
    return TA 


