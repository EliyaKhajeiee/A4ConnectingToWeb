# ds_protocol.py

# Starter code for assignment 3 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie
# ekhajeie@uci.edu
# 85362437

import json 
from collections import namedtuple

# Create a namedtuple to hold the values we expect to retrieve from json messages.
DataTuple = namedtuple('DataTuple', ['response', 'server_type'])

def extract_json(json_msg: str) -> DataTuple:
    try:
        json_obj = json.loads(json_msg)
        response = json_obj['response']
        server_type = json_obj['response']['type']
    except json.JSONDecodeError:
        print("Json cannot be decoded.")
        return None
    except KeyError as e:
        print(f'Missing key in JSON message : {e}')
        return None

    return DataTuple(response, server_type)
