# openweather.py

# Starter code for assignment 4 in ICS 32
# Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie 
# ekhajeie@uci.edu
# 85362437
import urllib.request
import urllib.error

from WebAPI import WebAPI
import re
'''Open Weather moduels which takes the openweather api and returns data in forms of a json data file'''
class OpenWeather(WebAPI):

    def __init__(self,zipcode="92697",ccode="US"):
        super().__init__()
        self.zipcode = zipcode
        self.ccode = ccode

    def set_apikey(self, apikey="d9049fe7b8cb819c14bcf4c070dbb5fc") -> None:
        self.apikey = apikey

    def load_data(self) -> None:
        try:
            url = f"http://api.openweathermap.org/data/2.5/weather?zip={self.zipcode},{self.ccode}&units=imperial&appid={self.apikey}"
            data = super()._download_url(url)
            self.longitude = data['coord']['lon']
            self.latitude = data['coord']['lat']
            self.weather = data['weather'][0]['main'] #used for @weather 
            self.description = data['weather'][0]['description']
            self.temperature = data['main']['temp']
            self.low_temperature = data['main']['temp_min']
            self.high_temperature = data['main']['temp_max']
            self.humidity = data['main']['humidity']
            self.sunset = data['sys']['sunset']
            self.city = data['name']
        except urllib.request.HTTPError as e:
            print("An error occured", e.code)
            quit()
        except ConnectionError as e:
            print("You have a connection error")
            quit()
        except (KeyError, TypeError) as e:
            print("You have inputted the wrong command, try again")
            print(e)
            quit()
        
    def transclude(self, message:str) -> str:

        if len(message) > 0 and not message.isspace():
            if re.search(r"@\bweather\b(?!([\w-]+))", message):
                replaceW = main(self.zipcode,self.ccode)
                message = message.replace("@weather", replaceW)
                return message #new message 
            else:
                pass

def current_weather(zipcode="92697",ccode="US") -> str:
    open_weather = OpenWeather(zipcode, ccode)
    open_weather.set_apikey()
    open_weather.load_data()
    return open_weather.weather

def main(zipcode,ccode):
    CW = current_weather(zipcode,ccode)
    return CW
