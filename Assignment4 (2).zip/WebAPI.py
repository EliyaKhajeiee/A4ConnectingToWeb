# webapi.py

# Starter code for assignment 4 in ICS 32
# Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie 
# ekhajeie@uci.edu
# 85362437
'''WebAPI which takes a URL and gives back json data'''
from abc import ABC, abstractmethod
import urllib, json
from urllib import request,error

class WebAPI(ABC): #api key d9049fe7b8cb819c14bcf4c070dbb5fc    
  def _download_url(self,url_to_download: str) -> dict: #this takes a url and gives back json data 
    response = None
    r_obj = None
    try:
        response = urllib.request.urlopen(url_to_download)
        json_results = response.read()
        r_obj = json.loads(json_results)

    except urllib.error.HTTPError as e:
        print('Failed to download contents of URL')
        print('Status code: {}'.format(e.code))

    finally:
      if response != None:
        response.close()
      
    return(r_obj)
  
def main() -> None:
   pass



if __name__ == '__main__':
    main()
    pass

def set_apikey(self, apikey:str) -> None:
    self.apikey = apikey

@abstractmethod
def load_data(self):
  pass

@abstractmethod
def transclude(self, message:str) -> str:
  pass
