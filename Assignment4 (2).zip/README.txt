This is a play on a3 in which now we will add upon the addposts function and be able to do a @weather and @lastfm which retreive diffrent forms of data and put them into 
a transluce message. I have mutlple different modules to test my code with unit testing. I still can use all my other functrions from a1,a2,a3 with the different
file systems. The errors that may occur are that my pycode tests arent hitting all the parts that they need to hit and that the code can be a little repetitive running
some functions multiple times. Overall this should work yet might be a little slow and not too efficent.
